var secretButton = document.querySelector('#secret-button');
var secretParagraph = document.querySelector('#secret-paragraph');
